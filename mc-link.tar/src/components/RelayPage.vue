<script setup lang="ts">
import { ref, computed, watch, onMounted } from "vue";
import { invoke } from "@tauri-apps/api/core";
import { getNodes, type RevampNode } from "../lib/revamp";

const props = defineProps<{
  showToast: (msg: string) => void;
}>();

interface RelayInfo {
  id: string;
  name: string;
  address: string;
}

interface IpInfo {
  region: string;
  isp: string;
}

const AUTO_ID = "__auto__";

function loadCachedRelayList(): RelayInfo[] {
  try {
    const cached = localStorage.getItem("relay_list");
    return cached ? JSON.parse(cached) : [];
  } catch { return []; }
}

// ===== Tab =====
const activeTab = ref<"mclink" | "revamp">(
  (localStorage.getItem("relay_tab") as "mclink" | "revamp") || "mclink"
);
watch(activeTab, (val) => localStorage.setItem("relay_tab", val));

// ===== 搜索 =====
const searchQuery = ref("");

// ===== MC Link 中继 =====
const relayList = ref<RelayInfo[]>(loadCachedRelayList());
const selectedRelay = ref<string | null>(localStorage.getItem("relay_selected") || AUTO_ID);
watch(selectedRelay, (val) => {
  localStorage.setItem("relay_selected", val || AUTO_ID);
});
const customRelay = ref<{ address: string; latency: number; pinging: boolean } | null>(null);
const ipInfoMap = ref<Record<string, IpInfo>>(loadCachedIpInfo());

function loadCachedIpInfo(): Record<string, IpInfo> {
  try {
    const cached = localStorage.getItem("relay_ipinfo");
    return cached ? JSON.parse(cached) : {};
  } catch { return {}; }
}
let pingTimer: ReturnType<typeof setTimeout> | null = null;

interface RelayEntry {
  id: string;
  name: string;
  address: string;
  isAuto: boolean;
}

const autoEntry: RelayEntry = { id: AUTO_ID, name: "自动选择", address: "自动选择最优中继节点", isAuto: true };

const filteredEntries = computed(() => {
  const q = searchQuery.value.toLowerCase();
  const matches = (entry: RelayEntry) => {
    if (entry.isAuto) return !q || "自动选择".includes(q) || "自动选择最优中继节点".includes(q);
    const info = ipInfoMap.value[entry.address];
    const ipMatch = info ? `${info.region} ${info.isp}`.toLowerCase().includes(q) : false;
    return !q || entry.name.toLowerCase().includes(q) || entry.address.toLowerCase().includes(q) || ipMatch;
  };
  const entries: RelayEntry[] = [autoEntry, ...relayList.value.map(r => ({ ...r, isAuto: false }))];
  return entries.filter(matches);
});

function extractHost(addr: string): string {
  const idx = addr.lastIndexOf(':');
  return idx > 0 ? addr.slice(0, idx) : addr;
}

async function fetchIpInfo(addr: string) {
  if (ipInfoMap.value[addr]) return;
  const host = extractHost(addr);
  try {
    const info = await invoke<IpInfo>("get_ip_info", { host });
    ipInfoMap.value = { ...ipInfoMap.value, [addr]: info };
    try { localStorage.setItem("relay_ipinfo", JSON.stringify(ipInfoMap.value)); } catch {}
  } catch (e: any) {
    props.showToast(`查询 ${host} 节点地域失败：${e}`);
    ipInfoMap.value = { ...ipInfoMap.value, [addr]: { region: "", isp: "" } };
  }
}

watch([searchQuery, activeTab], ([q]) => {
  if (activeTab.value !== "mclink") return;
  if (pingTimer) clearTimeout(pingTimer);
  customRelay.value = null;

  const hasAddr = /[.:]/.test(q);
  if (!hasAddr) return;

  customRelay.value = { address: q, latency: 0, pinging: true };
  pingTimer = setTimeout(async () => {
    try {
      const ms = await invoke<number>("ping_relay", { address: q });
      customRelay.value = { address: q, latency: ms, pinging: false };
      fetchIpInfo(q);
    } catch {
      customRelay.value = null;
    }
  }, 500);
});

// ===== MC Link revamp 节点 =====
const revampNodes = ref<RevampNode[]>([]);
const revampOnline = ref(false);
const revampLoading = ref(false);
const selectedNode = ref<string | null>(localStorage.getItem("revamp_node_selected") || null);
watch(selectedNode, (val) => {
  if (val) localStorage.setItem("revamp_node_selected", val);
  else localStorage.removeItem("revamp_node_selected");
});

const filteredRevampNodes = computed(() => {
  const q = searchQuery.value.toLowerCase();
  if (!q) return revampNodes.value;
  return revampNodes.value.filter(n =>
    n.name.toLowerCase().includes(q) ||
    n.ip.toLowerCase().includes(q) ||
    `${n.ip}:${n.port}`.includes(q) ||
    (n.contributor || "").toLowerCase().includes(q)
  );
});

async function fetchRevampNodes() {
  revampLoading.value = true;
  try {
    revampOnline.value = true;
    revampNodes.value = await getNodes();
  } catch (e: any) {
    revampOnline.value = false;
    revampNodes.value = [];
  } finally {
    revampLoading.value = false;
  }
}

function selectRevampNode(node: RevampNode) {
  selectedNode.value = `${node.ip}:${node.port}`;
}

// ===== 初始化 =====
onMounted(async () => {
  // 加载 MC Link 中继
  try {
    const relays = await invoke<RelayInfo[]>("get_relays");
    relayList.value = relays;
    localStorage.setItem("relay_list", JSON.stringify(relays));
    for (const r of relays) {
      fetchIpInfo(r.address);
    }
  } catch (e) {
    console.error("获取中继列表失败", e);
  }

  // 加载 revamp 节点
  fetchRevampNodes();
});
</script>

<template>
  <div>
    <!-- 标签栏 -->
    <div class="relay-tab-bar">
      <button
        :class="['relay-tab-btn', { active: activeTab === 'mclink' }]"
        @click="activeTab = 'mclink'"
      >
        <i class="bi bi-link-45deg"></i>
        <span>MC Link</span>
      </button>
      <button
        :class="['relay-tab-btn', { active: activeTab === 'revamp' }]"
        @click="activeTab = 'revamp'"
      >
        <i class="bi bi-arrow-repeat"></i>
        <span>MC Link revamp</span>
      </button>
    </div>

    <!-- 搜索框 -->
    <div class="relay-search-wrap">
      <i class="bi bi-search"></i>
      <input
        v-model="searchQuery"
        class="relay-search"
        :placeholder="activeTab === 'mclink' ? '搜索或输入节点地址' : '搜索节点名称、地址或贡献者'"
      />
    </div>

    <!-- MC Link 中继列表 -->
    <div v-if="activeTab === 'mclink'" class="relay-list">
      <div
        v-for="entry in filteredEntries"
        :key="entry.id"
        class="relay-card"
        :class="{ selected: selectedRelay === entry.id }"
        @click="selectedRelay = entry.id"
      >
        <div class="relay-card-left">
          <i v-if="entry.isAuto" class="bi bi-router"></i>
          <i v-else class="bi bi-hdd-network"></i>
          <div>
            <span class="relay-name">{{ entry.name }}</span>
            <span class="relay-addr">
              {{ entry.address }}
              <span v-if="ipInfoMap[entry.address]?.region" class="relay-ipinfo">
                {{ ipInfoMap[entry.address].region }} · {{ ipInfoMap[entry.address].isp }}
              </span>
              <span v-else-if="ipInfoMap[entry.address]" class="relay-ipinfo unknown">未知</span>
            </span>
          </div>
        </div>
        <i v-if="selectedRelay === entry.id" class="bi bi-check-circle-fill check-icon"></i>
      </div>

      <div
        v-if="customRelay && !customRelay.pinging"
        class="relay-card"
        :class="{ selected: selectedRelay === customRelay.address }"
        @click="selectedRelay = customRelay!.address"
      >
        <div class="relay-card-left">
          <i class="bi bi-plug"></i>
          <div>
            <span class="relay-name">{{ customRelay.address }}</span>
            <span class="relay-addr">
              {{ customRelay.latency }}ms
              <span v-if="ipInfoMap[customRelay.address]?.region" class="relay-ipinfo">
                {{ ipInfoMap[customRelay.address].region }} · {{ ipInfoMap[customRelay.address].isp }}
              </span>
              <span v-else-if="ipInfoMap[customRelay.address]" class="relay-ipinfo unknown">未知</span>
            </span>
          </div>
        </div>
        <i v-if="selectedRelay === customRelay.address" class="bi bi-check-circle-fill check-icon"></i>
      </div>

      <div v-if="customRelay && customRelay.pinging" class="text-muted" style="padding:20px 0;text-align:center">
        正在探测...
      </div>

      <div v-if="filteredEntries.length === 0 && !customRelay" class="text-muted" style="padding:30px 0;text-align:center">
        暂无匹配的中继服务器
      </div>
    </div>

    <!-- MC Link revamp 节点列表 -->
    <div v-else class="relay-list">
      <div v-if="revampLoading" class="text-muted" style="padding:20px 0;text-align:center">
        <span class="revamp-spinner-inline"></span>
        加载节点列表...
      </div>

      <div
        v-for="node in filteredRevampNodes"
        :key="node.ip + ':' + node.port"
        class="relay-card"
        :class="{ selected: selectedNode === node.ip + ':' + node.port }"
        @click="selectRevampNode(node)"
      >
        <div class="relay-card-left">
          <i class="bi bi-hdd-network"></i>
          <div>
            <span class="relay-name">{{ node.name || node.ip }}</span>
            <span class="relay-addr">
              {{ node.ip }}:{{ node.port }}
              <span v-if="node.contributor" class="relay-contributor">
                · 贡献者: {{ node.contributor }}
              </span>
            </span>
            <span v-if="node.last_update" class="relay-update">
              最后更新: {{ node.last_update }}
            </span>
          </div>
        </div>
        <i v-if="selectedNode === node.ip + ':' + node.port" class="bi bi-check-circle-fill check-icon"></i>
      </div>

      <div v-if="revampNodes.length === 0 && !revampLoading && revampOnline" class="text-muted" style="padding:30px 0;text-align:center">
        暂无可用节点
      </div>

      <div v-if="!revampOnline && !revampLoading" class="revamp-offline">
        <i class="bi bi-exclamation-triangle"></i>
        无法连接 revamp 中央服务器
        <button class="revamp-retry-btn" @click="fetchRevampNodes">重试</button>
      </div>

      <div v-if="filteredRevampNodes.length === 0 && revampNodes.length > 0 && searchQuery" class="text-muted" style="padding:30px 0;text-align:center">
        没有匹配的节点
      </div>
    </div>
  </div>
</template>

<style scoped>
/* ===== 标签栏（联机页面风格） ===== */
.relay-tab-bar {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-bottom: 16px;
  padding-bottom: 0;
}

.relay-tab-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 20px;
  border: none;
  background: transparent;
  color: var(--text-muted);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
  transition: all 0.15s ease;
}

.relay-tab-btn i {
  font-size: 15px;
}

.relay-tab-btn:hover {
  color: var(--text-secondary);
  background: var(--bg-hover);
  border-radius: 8px 8px 0 0;
}

.relay-tab-btn.active {
  color: var(--accent-primary);
  border-bottom-color: var(--accent-primary);
}

/* ===== 搜索框 ===== */
.relay-search-wrap {
  position: relative;
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.08);
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  transition: all 0.2s ease;
}

.relay-search-wrap:focus-within {
  background: rgba(255, 255, 255, 0.12);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.relay-search-wrap i:first-child {
  position: absolute;
  left: 12px;
  font-size: 14px;
  color: var(--text-muted);
  pointer-events: none;
  z-index: 1;
}

.relay-search {
  width: 100%;
  padding: 12px 14px 12px 34px;
  border: none;
  border-radius: 8px;
  font-size: 13px;
  box-sizing: border-box;
  background: transparent;
  color: var(--text-primary);
  outline: none;
}

.relay-search::placeholder {
  color: var(--text-muted);
}

/* ===== 列表 ===== */
.relay-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 16px;
}

.relay-card {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 14px 16px;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.relay-card:hover {
  border-color: var(--accent-primary);
  background: rgba(255, 255, 255, 0.05);
}

.relay-card-left {
  display: flex;
  align-items: center;
  gap: 14px;
  font-size: 22px;
  color: var(--accent-primary);
}

.relay-card-left div {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.relay-name {
  color: var(--text-primary);
  font-size: 14px;
  font-weight: 500;
}

.relay-addr {
  color: var(--text-muted);
  font-size: 12px;
}

.relay-ipinfo {
  color: var(--accent-primary);
  opacity: 0.8;
  font-size: 11px;
  margin-left: 4px;
}

.relay-ipinfo.unknown {
  color: var(--text-muted);
  opacity: 0.6;
}

.relay-card.selected {
  border-color: var(--accent-primary);
  background: rgba(0, 102, 204, 0.08);
  box-shadow: 0 2px 12px rgba(0, 102, 204, 0.2);
}

.check-icon {
  font-size: 18px;
  color: var(--accent-primary);
  flex-shrink: 0;
}

.relay-contributor {
  color: var(--text-muted);
  opacity: 0.7;
  font-size: 11px;
  margin-left: 2px;
}

.relay-update {
  color: var(--text-muted);
  opacity: 0.5;
  font-size: 11px;
}

/* ===== revamp 离线状态 ===== */
.revamp-offline {
  padding: 30px 0;
  text-align: center;
  color: var(--text-muted);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.revamp-offline i {
  font-size: 24px;
  color: var(--text-muted);
  opacity: 0.6;
}

.revamp-retry-btn {
  margin-top: 4px;
  padding: 6px 16px;
  border: 1px solid var(--border-color);
  border-radius: 6px;
  background: transparent;
  color: var(--text-secondary);
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.revamp-retry-btn:hover {
  border-color: var(--accent-primary);
  color: var(--accent-primary);
}

.revamp-spinner-inline {
  display: inline-block;
  width: 14px;
  height: 14px;
  border: 2px solid var(--border-color);
  border-top-color: var(--accent-primary);
  border-radius: 50%;
  animation: revamp-spin 0.6s linear infinite;
  margin-right: 8px;
  vertical-align: middle;
}

@keyframes revamp-spin {
  to { transform: rotate(360deg); }
}
</style>