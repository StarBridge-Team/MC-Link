<script setup lang="ts">
import { ref, watch, onMounted } from "vue";
import { invoke } from "@tauri-apps/api/core";
import { convertFileSrc } from "@tauri-apps/api/core";
import { version as vueVersion } from 'vue';
import { openUrl } from '@tauri-apps/plugin-opener';
import { registerAccount, loginAccount } from "../../lib/revamp";

const props = defineProps<{
  showToast: (msg: string) => void;
  activeTab: string;
  playerName?: string;
}>();

const emit = defineEmits<{
  (e: 'name-change', val: string): void;
}>();

const content = ref("");
const loading = ref(false);
const dirty = ref(false);

const tabLabels: Record<string, string> = {
  account: "账号",
  network: "网络",
  personalization: "个性化",
  adapter: "适配器",
  connector: "联机器",
  about: "关于",
};

interface Personalization {
  theme_color: string;
  theme_mode: string;
  animation_enabled: boolean;
  animation_speed: number;
  transparent_effect: string;
  background_type: string;
  background_value: string;
  background_fit: string;
  background_overlay: boolean;
  background_overlay_opacity: number;
  music_mode: string;
  music_value: string;
  homepage_mode: string;
  homepage_value: string;
}

const themePresets = [
  { name: "深邃蓝", color: "#0066cc" },
  { name: "翡翠绿", color: "#10b981" },
  { name: "罗兰紫", color: "#8b5cf6" },
  { name: "珊瑚红", color: "#ef4444" },
  { name: "琥珀橙", color: "#f59e0b" },
  { name: "樱花粉", color: "#ec4899" },
  { name: "极夜黑", color: "#1e1e2e" },
  { name: "冰川灰", color: "#6b7280" },
];

const effects = [
  { value: "none", label: "无" },
  { value: "transparent", label: "透明" },
  { value: "mica", label: "Mica (Windows 11)" },
  { value: "acrylic", label: "亚克力 (Windows 10)" },
  { value: "hud_window", label: "HUD Window (macOS)" },
];

const bgTypes = [
  { value: "default", label: "默认" },
  { value: "solid", label: "纯色" },
  { value: "transparent", label: "透明" },
  { value: "image", label: "图片" },
  { value: "video", label: "视频" },
];

const fitModes = [
  { value: "scale-to-fill", label: "拉伸填充" },
  { value: "aspect-fit", label: "等比适应" },
  { value: "aspect-fill", label: "等比填充" },
  { value: "width-fix", label: "宽度固定" },
  { value: "height-fix", label: "高度固定" },
];

const persLoading = ref(false);

interface BackgroundFileItem {
  name: string;
  is_video: boolean;
}
const backgroundFiles = ref<BackgroundFileItem[]>([]);
const bgFileLoading = ref(false);
const resolvedBgUrl = ref("");

const musicFiles = ref<BackgroundFileItem[]>([]);
const bgMusicUrlInput = ref("");

const homepageUrlInput = ref("");

function applyHomepageUrl() {
  const url = homepageUrlInput.value.trim();
  if (!url) return;
  persSettings.value.homepage_value = url;
  persSettings.value.homepage_mode = 'webpage';
  onPersChange();
}

function getMusicModes() {
  const modes = [
    { value: "none", label: "无" },
    { value: "file", label: "从文件加载" },
    { value: "url", label: "从URL加载" },
  ];
  if (persSettings.value.background_type === 'video' && persSettings.value.background_value) {
    modes.push({ value: "video", label: "使用视频音频" });
  }
  return modes;
}

function selectMusicFile(name: string) {
  persSettings.value.music_value = name;
  persSettings.value.music_mode = 'file';
  bgMusicUrlInput.value = '';
  onPersChange();
  applyPersStyle();
}

function applyMusicUrl() {
  const url = bgMusicUrlInput.value.trim();
  if (!url) return;
  persSettings.value.music_value = url;
  persSettings.value.music_mode = 'url';
  onPersChange();
  applyPersStyle();
}

// 跨组件挂载缓存个性化设置，退出页面再进来保留未保存的修改
let persCache: Personalization | null = null;

const persSettings = ref<Personalization>({
  theme_color: "#0066cc",
  theme_mode: "system",
  animation_enabled: true,
  animation_speed: 1.0,
  transparent_effect: "none",
  background_type: "default",
  background_value: "",
  background_fit: "scale-to-fill",
  background_overlay: false,
  background_overlay_opacity: 30,
  music_mode: "none",
  music_value: "",
  homepage_mode: "default",
  homepage_value: "",
});

async function loadPersonalization() {
  persLoading.value = true;
  try {
    if (persCache) {
      persSettings.value = { ...persCache };
    } else {
      const data = await invoke<Personalization>("get_personalization");
      // 兼容旧配置没有新字段
      if (!data.background_fit) data.background_fit = "scale-to-fill";
      if (!data.theme_mode) data.theme_mode = "system";
      if (data.background_overlay === undefined) data.background_overlay = false;
      if (!data.background_overlay_opacity) data.background_overlay_opacity = 30;
      if (!data.music_mode) data.music_mode = "none";
      if (!data.music_value) data.music_value = "";
      if (!data.homepage_mode) data.homepage_mode = "default";
      if (!data.homepage_value) data.homepage_value = "";
      persSettings.value = data;
      // 解析已保存的本地背景文件
      if (data.background_value && !data.background_value.startsWith('http')) {
        try {
          const filePath = await invoke<string>("get_background_file_url", { filename: data.background_value });
          resolvedBgUrl.value = convertFileSrc(filePath);
        } catch {
          resolvedBgUrl.value = "";
        }
      }
    }
  } catch {
  } finally {
    persLoading.value = false;
  }
  if (!persCache) applyPersStyle();
  loadBackgroundFiles();
}

const bgUrlInput = ref("");

async function loadBackgroundFiles() {
  bgFileLoading.value = true;
  try {
    const allFiles = await invoke<BackgroundFileItem[]>("get_background_files");
    backgroundFiles.value = allFiles;
    // 过滤出音频文件（非视频且非图片的不存在，直接用扩展名判断）
    musicFiles.value = allFiles.filter(f => {
      const ext = f.name.split('.').pop()?.toLowerCase();
      return ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'].includes(ext || '');
    });
  } catch {
    backgroundFiles.value = [];
    musicFiles.value = [];
  } finally {
    bgFileLoading.value = false;
  }
}

function selectBgFile(name: string, isVideo: boolean) {
  persSettings.value.background_value = name;
  persSettings.value.background_type = isVideo ? 'video' : 'image';
  bgUrlInput.value = '';
  // 异步解析后立即应用
  invoke<string>("get_background_file_url", { filename: name })
    .then(path => {
      resolvedBgUrl.value = convertFileSrc(path);
      applyPersStyle();
    })
    .catch(() => {
      resolvedBgUrl.value = '';
      applyPersStyle();
    });
  onPersChange();
}

function selectBgUrl() {
  const url = bgUrlInput.value.trim();
  if (!url) return;
  persSettings.value.background_value = url;
  // 根据扩展名或常见视频域名判断类型
  const isVideo = /\.(mp4|webm|avi|mov|mkv)(\?|$)/i.test(url) ||
    /(youtube\.com|youtu\.be|bilibili\.com)/i.test(url);
  persSettings.value.background_type = isVideo ? 'video' : 'image';
  onPersChange();
}

async function savePersonalization() {
  try {
    await invoke("save_personalization", { settings: persSettings.value });
    persCache = { ...persSettings.value };
  } catch (e: any) {
    props.showToast("保存失败: " + e);
  }
}

// 自动保存防抖
let autoSaveTimer: ReturnType<typeof setTimeout> | null = null;
function autoSave() {
  if (autoSaveTimer) clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(() => savePersonalization(), 400);
}

function applyPersStyle() {
  const root = document.documentElement;
  const s = persSettings.value;
  // 主题色
  root.style.setProperty('--accent-primary', s.theme_color);
  root.style.setProperty('--accent-hover', s.theme_color + '33');
  root.style.setProperty('--shadow-accent', s.theme_color + '40');
  // 动画
  if (s.animation_enabled) {
    root.classList.remove('no-animations');
    root.style.setProperty('--anim-speed', String(s.animation_speed));
  } else {
    root.classList.add('no-animations');
    root.style.setProperty('--anim-speed', '1');
  }
  // 主题模式
  root.setAttribute('data-theme-mode', s.theme_mode);
  // 背景
  const isFullBg = s.background_type !== 'default' && s.background_type !== 'transparent';
  if (isFullBg) {
    root.style.setProperty('--window-margin', '0');
    root.style.setProperty('--window-radius', '0');
  } else {
    root.style.removeProperty('--window-margin');
    root.style.removeProperty('--window-radius');
  }
  switch (s.background_type) {
    case 'default':
      root.style.removeProperty('--window-container-bg');
      root.style.removeProperty('--titlebar-bg');
      root.style.removeProperty('--window-wrapper-bg');
      root.style.removeProperty('--window-wrapper-bg-image');
      root.style.removeProperty('--window-wrapper-bg-fit');
      break;
    case 'transparent':
      root.style.setProperty('--window-container-bg', 'transparent');
      root.style.setProperty('--titlebar-bg', 'transparent');
      root.style.removeProperty('--window-wrapper-bg');
      root.style.removeProperty('--window-wrapper-bg-image');
      root.style.removeProperty('--window-wrapper-bg-fit');
      break;
    case 'solid':
      root.style.setProperty('--window-wrapper-bg', s.background_value || '#18191a');
      root.style.setProperty('--window-container-bg', 'transparent');
      root.style.setProperty('--titlebar-bg', 'transparent');
      root.style.removeProperty('--window-wrapper-bg-image');
      root.style.removeProperty('--window-wrapper-bg-fit');
      break;
    case 'image': {
      root.style.setProperty('--window-container-bg', 'transparent');
      root.style.setProperty('--titlebar-bg', 'transparent');
      root.style.removeProperty('--window-wrapper-bg');
      if (s.background_value) {
        const isUrl = s.background_value.startsWith('http://') || s.background_value.startsWith('https://');
        const bgPath = isUrl ? s.background_value : resolvedBgUrl.value;
        if (bgPath) {
          root.style.setProperty('--window-wrapper-bg-image', `url("${bgPath}")`);
          root.style.setProperty('--window-wrapper-bg-fit', getFitCss(s.background_fit));
        } else {
          root.style.removeProperty('--window-wrapper-bg-image');
          root.style.removeProperty('--window-wrapper-bg-fit');
        }
      } else {
        root.style.removeProperty('--window-wrapper-bg-image');
        root.style.removeProperty('--window-wrapper-bg-fit');
      }
      break;
    }
    case 'video':
      root.style.setProperty('--window-container-bg', 'transparent');
      root.style.setProperty('--titlebar-bg', 'transparent');
      root.style.removeProperty('--window-wrapper-bg');
      root.style.removeProperty('--window-wrapper-bg-image');
      root.style.removeProperty('--window-wrapper-bg-fit');
      break;
    default:
      break;
  }
  // 透明效果：无透明时整个窗口背景用默认主题色
  if (s.transparent_effect === 'none' && s.background_type === 'default') {
    root.style.setProperty('--window-wrapper-bg', 'var(--bg-window)');
    root.style.setProperty('--titlebar-bg', 'var(--bg-window)');
  } else if (s.transparent_effect === 'none') {
    root.style.removeProperty('--window-wrapper-bg');
    root.style.setProperty('--titlebar-bg', 'var(--bg-window)');
  } else {
    root.style.removeProperty('--window-wrapper-bg');
    root.style.removeProperty('--titlebar-bg');
    if (s.transparent_effect === 'transparent') {
      root.style.setProperty('--transparent-overlay', 'rgba(0,0,0,0.4)');
    } else {
      root.style.removeProperty('--transparent-overlay');
    }
  }
  // 背景遮罩
  root.style.removeProperty('--bg-overlay');
  if (s.background_overlay && isFullBg) {
    root.style.setProperty('--bg-overlay', `rgba(0,0,0,${s.background_overlay_opacity / 100})`);
  }
  // 同步背景视频状态
  const vidEl = document.getElementById('bg-video') as HTMLVideoElement | null;
  if (s.background_type === 'video' && s.background_value) {
    const isUrl = s.background_value.startsWith('http://') || s.background_value.startsWith('https://');
    const videoSrc = isUrl ? s.background_value : resolvedBgUrl.value;
    if (vidEl && videoSrc) {
      if (vidEl.getAttribute('data-src') !== videoSrc) {
        vidEl.setAttribute('data-src', videoSrc);
        vidEl.src = videoSrc;
        vidEl.play().catch(() => {});
      }
      vidEl.style.display = 'block';
    }
  } else if (vidEl) {
    vidEl.style.display = 'none';
  }
  // 同步音乐
  syncMusic(s);
}

function syncMusic(s: Personalization) {
  const audioEl = document.getElementById('bg-music') as HTMLAudioElement | null;
  const vidEl = document.getElementById('bg-video') as HTMLVideoElement | null;
  // 重置视频静音状态
  if (vidEl) vidEl.muted = true;
  if (!audioEl) return;
  if (s.music_mode === 'video' && s.background_type === 'video') {
    // 使用视频音频 —— 取消视频静音
    if (vidEl) vidEl.muted = false;
    audioEl.pause();
    audioEl.src = '';
    audioEl.style.display = 'none';
    return;
  }
  if (s.music_mode === 'file' && s.music_value) {
    invoke<string>("get_background_file_url", { filename: s.music_value })
      .then(path => {
        audioEl.src = convertFileSrc(path);
        audioEl.style.display = '';
        audioEl.loop = true;
        audioEl.play().catch(() => {});
      })
      .catch(() => {});
  } else if (s.music_mode === 'url' && s.music_value) {
    audioEl.src = s.music_value;
    audioEl.style.display = '';
    audioEl.loop = true;
    audioEl.play().catch(() => {});
  } else {
    audioEl.pause();
    audioEl.src = '';
    audioEl.style.display = 'none';
  }
}

function getFitCss(fit: string): string {
  switch (fit) {
    case 'aspect-fit': return 'contain';
    case 'aspect-fill': return 'cover';
    case 'width-fix': return '100% auto';
    case 'height-fix': return 'auto 100%';
    default: return '100% 100%';
  }
}

function selectTheme(color: string) {
  persSettings.value.theme_color = color;
  onPersChange();
}

function setEffect(effect: string) {
  persSettings.value.transparent_effect = effect;
  invoke("set_window_effect", { effect }).catch(() => {});
  onPersChange();
}

function onPersChange() {
  applyPersStyle();
  autoSave();
}

function onNameInput(e: Event) {
  const val = (e.target as HTMLInputElement).value;
  localStorage.setItem("player_name", val);
  emit('name-change', val);
}

// About page data
// MC Link revamp 适配器账号
const revampServer = "43.248.79.27:14117";
const revampUsername = ref("");
const revampPassword = ref("");
const revampToken = ref(localStorage.getItem("revamp_token") || "");
const revampLoggedIn = ref(!!localStorage.getItem("revamp_token"));
const revampLoading = ref(false);
const revampActionText = ref("");

// 恢复已保存的用户名
const savedRevampUser = localStorage.getItem("revamp_username") || "";
if (savedRevampUser) revampUsername.value = savedRevampUser;

async function revampRegister() {
  if (!revampUsername.value || !revampPassword.value) {
    props.showToast("请输入用户名和密码");
    return;
  }
  revampLoading.value = true;
  revampActionText.value = "注册中...";
  try {
    const data = await registerAccount(revampUsername.value, revampPassword.value);
    if (data.status === "ok" || data.status === "success") {
      props.showToast("注册成功，请登录");
    } else {
      props.showToast("注册失败: " + (data.message || "未知错误"));
    }
  } catch (e: any) {
    props.showToast("注册失败: " + e);
  } finally {
    revampLoading.value = false;
    revampActionText.value = "";
  }
}

async function revampLogin() {
  if (!revampUsername.value || !revampPassword.value) {
    props.showToast("请输入用户名和密码");
    return;
  }
  revampLoading.value = true;
  revampActionText.value = "登录中...";
  try {
    const data = await loginAccount(revampUsername.value, revampPassword.value);
    if (data.status === "ok" || data.status === "success") {
      revampToken.value = data.token;
      revampLoggedIn.value = true;
      localStorage.setItem("revamp_token", data.token);
      localStorage.setItem("revamp_username", revampUsername.value);
      props.showToast("登录成功");
    } else {
      props.showToast("登录失败: " + (data.message || "用户名或密码错误"));
    }
  } catch (e: any) {
    props.showToast("登录失败: " + e);
  } finally {
    revampLoading.value = false;
    revampActionText.value = "";
  }
}

function revampLogout() {
  revampToken.value = "";
  revampLoggedIn.value = false;
  localStorage.removeItem("revamp_token");
  props.showToast("已登出");
}

const appVersion = ref("");
const tauriVersion = ref("");

onMounted(async () => {
  try {
    appVersion.value = await invoke<string>("get_app_version");
    tauriVersion.value = await invoke<string>("get_tauri_version");
  } catch {
    appVersion.value = "?";
    tauriVersion.value = "?";
  }
});

async function loadContent() {
  loading.value = true;
  try {
    const result = await invoke<string>("get_setting", { section: props.activeTab });
    content.value = result;
  } catch {
    content.value = "# " + (tabLabels[props.activeTab] || props.activeTab) + "\n# 暂无配置\n";
  } finally {
    loading.value = false;
    dirty.value = false;
  }
}

async function saveContent() {
  try {
    await invoke("save_setting", { section: props.activeTab, content: content.value });
    props.showToast("设置已保存");
    dirty.value = false;
  } catch (e: any) {
    props.showToast("保存失败: " + e);
  }
}

function onContentInput(e: Event) {
  content.value = (e.target as HTMLTextAreaElement).value;
  dirty.value = true;
}

watch(() => props.activeTab, (val) => {
  if (val === 'personalization') {
    loadPersonalization();
  } else if (val !== 'about') {
    loadContent();
  }
});
</script>

<template>
  <div class="setting-page">
    <div class="setting-content">
      <div class="setting-content-header">
        <h3>{{ tabLabels[activeTab] || activeTab }}</h3>
        <div class="setting-content-actions" v-if="activeTab !== 'about' && activeTab !== 'personalization'">
          <button
            class="btn btn-primary"
            :disabled="!dirty"
            @click="saveContent"
          >
            <i class="bi bi-check-lg"></i>
            保存
          </button>
        </div>
      </div>

      <!-- 关于页面 -->
      <div v-if="activeTab === 'about'" class="about-page">
        <div class="about-card">
          <div class="about-card-left">
            <div class="about-icon">
              <img src="/mc-link-icon.png" alt="MC Link" class="about-icon-img" />
            </div>
          </div>
          <div class="about-card-right">
            <div class="about-title-row">
              <span class="about-app-name">MC Link</span>
              <span class="about-version-badge">{{ appVersion }}</span>
            </div>
            <div class="about-meta-row">
              <span class="about-meta-item">
                <span class="about-meta-label">Vue</span>
                <span class="about-meta-value">{{ vueVersion }}</span>
              </span>
              <span class="about-meta-divider"></span>
              <span class="about-meta-item">
                <span class="about-meta-label">Tauri</span>
                <span class="about-meta-value">{{ tauriVersion }}</span>
              </span>
            </div>
            <div class="about-links">
              <a class="about-link" @click="openUrl('https://mclink.nsrwz.cn')" title="官网">
                <i class="bi bi-globe2"></i>
                mclink.nsrwz.cn
              </a>
              <a class="about-link" @click="openUrl('https://github.com/DogerMMC/mc-link')" title="GitHub">
                <i class="bi bi-github"></i>
                DogerMMC/mc-link
              </a>
            </div>
          </div>
        </div>

        <div class="about-card">
          <div class="about-card-body">
            <div class="about-card-title">开发者</div>
            <div class="about-dev-list">
              <div class="about-dev-item">
                <img class="about-avatar" src="http://q.qlogo.cn/g?b=qq&nk=196783749&s=640" alt="avatar" />
                <div class="about-dev-info">
                  <span class="about-dev-name">粗狗</span>
                  <span class="about-dev-role">项目发起人 / 核心开发</span>
                </div>
              </div>
              <div class="about-dev-item">
                <img class="about-avatar" src="http://q.qlogo.cn/g?b=qq&nk=3995090331&s=640" alt="avatar" />
                <div class="about-dev-info">
                  <span class="about-dev-name">oiiaio猫</span>
                  <span class="about-dev-role">Python开发</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="about-card">
          <div class="about-card-body">
            <div class="about-card-title">鸣谢</div>
            <div class="about-dev-list">
              <div class="about-dev-item">
                <img class="about-avatar" src="http://q.qlogo.cn/g?b=qq&nk=1508668973&s=640" alt="avatar" />
                <div class="about-dev-info">
                  <span class="about-dev-name">烤鱼</span>
                  <span class="about-dev-role">节点贡献者 / 找bug小能手</span>
                </div>
              </div>
              <div class="about-dev-item">
                <img class="about-avatar" src="http://q.qlogo.cn/g?b=qq&nk=3680388074&s=640" alt="avatar" />
                <div class="about-dev-info">
                  <span class="about-dev-name">雨凉</span>
                  <span class="about-dev-role">工作室核心成员 / 节点贡献者</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 账号页面 -->
      <div v-else-if="activeTab === 'account'" class="personalization-page">
        <div class="pers-card">
          <div class="pers-card-title">玩家信息</div>
          <div class="pers-row">
            <span>玩家名</span>
            <input
              class="pers-input"
              :value="playerName"
              @input="onNameInput"
              placeholder="输入玩家名"
              maxlength="16"
            />
          </div>
        </div>

        <!-- MC Link revamp 适配器账号 -->
        <div class="pers-card" style="margin-top: 16px; position: relative;">
          <div class="pers-card-title">
            MC Link revamp 适配器账号
            <span class="revamp-badge">适配器</span>
          </div>
          <div class="revamp-server-info">
            <i class="bi bi-server"></i>
            服务器: <code>{{ revampServer }}</code>
          </div>
          <div class="pers-row">
            <span>状态</span>
            <span :class="revampLoggedIn ? 'revamp-status-online' : 'revamp-status-offline'">
              <i :class="revampLoggedIn ? 'bi bi-check-circle-fill' : 'bi bi-x-circle-fill'"></i>
              {{ revampLoggedIn ? '已登录' : '未登录' }}
            </span>
          </div>

          <!-- 加载遮罩 -->
          <div v-if="revampLoading" class="revamp-loading-overlay">
            <div class="revamp-spinner"></div>
            <span>{{ revampActionText }}</span>
          </div>

          <template v-if="!revampLoggedIn">
            <div class="pers-row">
              <span>用户名</span>
              <input
                class="pers-input"
                v-model="revampUsername"
                placeholder="输入用户名"
                maxlength="32"
              />
            </div>
            <div class="pers-row">
              <span>密码</span>
              <input
                class="pers-input"
                type="password"
                v-model="revampPassword"
                placeholder="输入密码"
                @keyup.enter="revampLogin"
              />
            </div>
            <div class="revamp-actions">
              <button class="btn btn-primary" :disabled="revampLoading" @click="revampRegister">
                <i class="bi bi-person-plus"></i>
                注册
              </button>
              <button class="btn" :class="{ 'btn-primary': !revampLoading }" :disabled="revampLoading" @click="revampLogin">
                <i class="bi bi-box-arrow-in-right"></i>
                登录
              </button>
            </div>
          </template>
          <template v-else>
            <div class="pers-row">
              <span>已登录用户</span>
              <span class="revamp-user">{{ revampUsername }}</span>
            </div>
            <div class="revamp-actions">
              <button class="btn" @click="revampLogout">
                <i class="bi bi-box-arrow-right"></i>
                登出
              </button>
            </div>
          </template>
        </div>
      </div>

      <!-- 个性化页面 -->
      <div v-else-if="activeTab === 'personalization'" class="personalization-page">
        <div v-if="persLoading" class="setting-loading">加载中...</div>
        <template v-else>
          <!-- 主题色 -->
          <div class="pers-card">
            <div class="pers-card-title">主题色</div>
            <div class="pers-colors">
              <div
                v-for="preset in themePresets"
                :key="preset.color"
                class="pers-color-item"
                :class="{ active: persSettings.theme_color === preset.color }"
                @click="selectTheme(preset.color)"
              >
                <div class="pers-color-swatch" :style="{ background: preset.color }">
                  <i v-if="persSettings.theme_color === preset.color" class="bi bi-check-lg"></i>
                </div>
                <span class="pers-color-name">{{ preset.name }}</span>
              </div>
              <div class="pers-color-item pers-color-custom">
                <label class="pers-color-swatch pers-color-picker" :style="{ background: persSettings.theme_color }">
                  <input type="color" v-model="persSettings.theme_color" class="pers-color-input" @input="onPersChange" />
                  <i class="bi bi-eyedropper"></i>
                </label>
                <span class="pers-color-name">自定义</span>
              </div>
            </div>
          </div>

          <!-- 动画 -->
          <div class="pers-card">
            <div class="pers-card-title">动画</div>
            <div class="pers-row">
              <span>启用动画</span>
              <label class="pers-toggle">
                <input type="checkbox" v-model="persSettings.animation_enabled" @change="onPersChange" />
                <span class="pers-toggle-slider"></span>
              </label>
            </div>
            <div class="pers-row" v-if="persSettings.animation_enabled">
              <span>动画速度</span>
              <div class="pers-speed">
                <input
                  type="range"
                  min="0.25"
                  max="2"
                  step="0.25"
                  v-model.number="persSettings.animation_speed"
                  @input="onPersChange"
                  class="pers-slider"
                />
                <span class="pers-speed-label">{{ persSettings.animation_speed }}x</span>
              </div>
            </div>
          </div>

          <!-- 透明效果 -->
          <div class="pers-card">
            <div class="pers-card-title">透明效果</div>
            <div class="pers-effects">
              <div
                v-for="effect in effects"
                :key="effect.value"
                class="pers-effect-item"
                :class="{ active: persSettings.transparent_effect === effect.value }"
                @click="setEffect(effect.value)"
              >
                {{ effect.label }}
              </div>
            </div>
          </div>

          <!-- 背景 -->
          <div class="pers-card">
            <div class="pers-card-title">背景</div>
            <div class="pers-bg-types">
              <div
                v-for="bt in bgTypes"
                :key="bt.value"
                class="pers-bg-type-item"
                :class="{ active: persSettings.background_type === bt.value }"
                @click="persSettings.background_type = bt.value; onPersChange()"
              >
                {{ bt.label }}
              </div>
            </div>
            <!-- 纯色 -->
            <div v-if="persSettings.background_type === 'solid'" class="pers-bg-solid">
              <input type="color" v-model="persSettings.background_value" class="pers-color-input-inline" @input="autoSave" />
              <span class="pers-color-hex">{{ persSettings.background_value || '#18191a' }}</span>
            </div>
            <!-- 图片/视频 -->
            <div v-if="persSettings.background_type === 'image' || persSettings.background_type === 'video'" class="pers-bg-media">
              <!-- 适应模式 -->
              <div class="pers-bg-section">
                <div class="pers-bg-section-label">适应模式</div>
                <div class="pers-fit-modes">
                  <div
                    v-for="fm in fitModes"
                    :key="fm.value"
                    class="pers-fit-item"
                    :class="{ active: persSettings.background_fit === fm.value }"
                    @click="persSettings.background_fit = fm.value; onPersChange()"
                  >
                    {{ fm.label }}
                  </div>
                </div>
              </div>
              <!-- 本地文件 -->
              <div class="pers-bg-section">
                <div class="pers-bg-section-label">本地文件 (Background 文件夹)</div>
                <div v-if="bgFileLoading" class="pers-bg-loading">扫描中...</div>
                <div v-else-if="backgroundFiles.length === 0" class="pers-bg-empty">暂无文件，请将图片/视频放入 Background 文件夹</div>
                <div v-else class="pers-bg-files">
                  <div
                    v-for="f in backgroundFiles"
                    :key="f.name"
                    class="pers-bg-file"
                    :class="{ active: persSettings.background_value === f.name && !persSettings.background_value.startsWith('http') }"
                    @click="selectBgFile(f.name, f.is_video)"
                  >
                    <i :class="f.is_video ? 'bi bi-film' : 'bi bi-file-earmark-image'"></i>
                    <span class="pers-bg-file-name">{{ f.name }}</span>
                  </div>
                </div>
              </div>
              <!-- URL -->
              <div class="pers-bg-section">
                <div class="pers-bg-section-label">URL 链接</div>
                <div class="pers-bg-url-row">
                  <input
                    class="pers-input pers-bg-url-input"
                    v-model="bgUrlInput"
                    placeholder="输入图片/视频 URL"
                    @keyup.enter="selectBgUrl"
                  />
                  <button class="btn btn-primary pers-bg-url-btn" @click="selectBgUrl">应用</button>
                </div>
              </div>
              <!-- 当前选中 -->
              <div v-if="persSettings.background_value" class="pers-bg-current">
                当前: {{ persSettings.background_value }}
              </div>
            </div>
          </div>

          <!-- 主题模式 -->
          <div class="pers-card">
            <div class="pers-card-title">主题模式</div>
            <div class="pers-effects">
              <div
                v-for="mode in [{value:'system',label:'跟随系统'},{value:'light',label:'浅色'},{value:'dark',label:'深色'}]"
                :key="mode.value"
                class="pers-effect-item"
                :class="{ active: persSettings.theme_mode === mode.value }"
                @click="persSettings.theme_mode = mode.value; onPersChange()"
              >
                {{ mode.label }}
              </div>
            </div>
          </div>

          <!-- 背景遮罩 -->
          <div class="pers-card">
            <div class="pers-card-title">背景遮罩</div>
            <div class="pers-row">
              <span>启用遮罩</span>
              <div class="pers-toggle" :class="{ active: persSettings.background_overlay }" @click="persSettings.background_overlay = !persSettings.background_overlay; onPersChange()">
                <div class="pers-toggle-knob"></div>
              </div>
            </div>
            <div v-if="persSettings.background_overlay" class="pers-slider-row">
              <span>遮罩透明度</span>
              <input type="range" min="0" max="100" v-model.number="persSettings.background_overlay_opacity" class="pers-range" @input="onPersChange" />
              <span class="pers-range-value">{{ persSettings.background_overlay_opacity }}%</span>
            </div>
          </div>

          <!-- 音乐 -->
          <div class="pers-card">
            <div class="pers-card-title">背景音乐</div>
            <div class="pers-music-modes">
              <div
                v-for="m in getMusicModes()"
                :key="m.value"
                class="pers-music-mode-item"
                :class="{ active: persSettings.music_mode === m.value }"
                @click="persSettings.music_mode = m.value; onPersChange()"
              >
                {{ m.label }}
              </div>
            </div>
            <div v-if="persSettings.music_mode === 'file'" class="pers-music-file">
              <div class="pers-bg-section-label">从 Background 文件夹选择音乐文件</div>
              <div v-if="musicFiles.length === 0" class="pers-bg-empty">暂无音频文件</div>
              <div v-else class="pers-bg-files">
                <div
                  v-for="f in musicFiles"
                  :key="f.name"
                  class="pers-bg-file"
                  :class="{ active: persSettings.music_value === f.name }"
                  @click="selectMusicFile(f.name)"
                >
                  <i class="bi bi-file-earmark-music"></i>
                  <span class="pers-bg-file-name">{{ f.name }}</span>
                </div>
              </div>
            </div>
            <div v-if="persSettings.music_mode === 'url'" class="pers-music-url">
              <div class="pers-bg-url-row">
                <input
                  class="pers-input pers-bg-url-input"
                  v-model="bgMusicUrlInput"
                  placeholder="输入音频 URL"
                  @keyup.enter="applyMusicUrl"
                />
                <button class="btn btn-primary pers-bg-url-btn" @click="applyMusicUrl">应用</button>
              </div>
            </div>
          </div>

          <!-- 自定义主页 -->
          <div class="pers-card">
            <div class="pers-card-title">自定义主页</div>
            <div class="pers-music-modes">
              <div
                v-for="h in [{value:'default',label:'默认'},{value:'blank',label:'空白'},{value:'webpage',label:'网页'}]"
                :key="h.value"
                class="pers-music-mode-item"
                :class="{ active: persSettings.homepage_mode === h.value }"
                @click="persSettings.homepage_mode = h.value; onPersChange()"
              >
                {{ h.label }}
              </div>
            </div>
            <div v-if="persSettings.homepage_mode === 'webpage'" class="pers-music-url">
              <div class="pers-bg-url-row">
                <input
                  class="pers-input pers-bg-url-input"
                  v-model="homepageUrlInput"
                  placeholder="输入主页 URL (https://...)"
                  @keyup.enter="applyHomepageUrl"
                />
                <button class="btn btn-primary pers-bg-url-btn" @click="applyHomepageUrl">应用</button>
              </div>
            </div>
          </div>
        </template>
      </div>

      <!-- 其他设置页面 -->
      <div v-else class="setting-editor">
        <div v-if="loading" class="setting-loading">加载中...</div>
        <textarea
          v-else
          class="setting-textarea"
          :value="content"
          @input="onContentInput"
          spellcheck="false"
        ></textarea>
      </div>
    </div>
  </div>
</template>

<style scoped>
.setting-page {
  height: 100%;
  display: flex;
}

.setting-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 20px 24px;
  overflow: hidden;
}

.setting-content-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.setting-content-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: var(--text-primary);
  flex: 1;
}

.setting-content-actions {
  display: flex;
  gap: 8px;
}

.btn {
  transition: all 0.2s ease;
  border-radius: 8px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 500;
  padding: 8px 16px;
  border: none;
  background: rgba(255, 255, 255, 0.1);
  color: var(--text-primary);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.btn:hover {
  background: rgba(255, 255, 255, 0.15);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-primary {
  background: var(--accent-primary);
  color: #ffffff;
  box-shadow: 0 2px 8px rgba(0, 102, 204, 0.3);
}

.btn-primary:hover:not(:disabled) {
  background: var(--accent-hover);
}

.setting-editor {
  flex: 1;
  overflow: hidden;
  position: relative;
}

.setting-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: var(--text-muted);
  font-size: 14px;
}

.setting-textarea {
  width: 100%;
  height: 100%;
  padding: 16px;
  border: 1px solid var(--border-color);
  border-radius: 10px;
  background: var(--bg-tertiary);
  color: var(--text-primary);
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
  font-size: 13px;
  line-height: 1.6;
  resize: none;
  outline: none;
  box-sizing: border-box;
  transition: border-color 0.2s ease;
}

.setting-textarea:focus {
  border-color: var(--accent-primary);
}

/* ===== 关于页面 ===== */
.about-page {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 16px;
  overflow-y: auto;
}

.about-card {
  background: var(--bg-card, rgba(255,255,255,0.06));
  border: 1px solid var(--border-color, rgba(255,255,255,0.08));
  border-radius: 12px;
  padding: 24px;
  display: flex;
  align-items: flex-start;
  gap: 20px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}

.about-card-left {
  flex-shrink: 0;
}

.about-icon {
  width: 64px;
  height: 64px;
  border-radius: 14px;
  overflow: hidden;
}

.about-icon-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.about-card-right {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.about-title-row {
  display: flex;
  align-items: center;
  gap: 10px;
}

.about-app-name {
  font-size: 20px;
  font-weight: 700;
  color: var(--text-primary);
}

.about-version-badge {
  display: inline-block;
  padding: 2px 10px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  background: var(--accent-primary);
  color: #fff;
  line-height: 1.6;
}

.about-meta-row {
  display: flex;
  align-items: center;
  gap: 12px;
}

.about-meta-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

.about-meta-label {
  font-size: 12px;
  color: var(--text-muted);
  font-weight: 500;
}

.about-meta-value {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-primary);
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
}

.about-meta-divider {
  width: 1px;
  height: 14px;
  background: var(--border-color, rgba(255,255,255,0.15));
}

.about-links {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-top: 4px;
}

.about-link {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: var(--text-muted);
  cursor: pointer;
  text-decoration: none;
  transition: color 0.15s ease;
}

.about-link:hover {
  color: var(--accent-primary);
}

.about-link i {
  font-size: 14px;
}

/* 卡片正文布局 */
.about-card-body {
  flex: 1;
  min-width: 0;
}

.about-card-title {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 6px;
}

.about-card-desc {
  font-size: 13px;
  color: var(--text-muted);
  line-height: 1.6;
}

.about-dev-item {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 18px;
  color: var(--text-primary);
  padding: 16px 0;
}

.about-dev-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.about-dev-item i {
  font-size: 16px;
}

.about-dev-info {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.about-dev-name {
  font-size: 18px;
  font-weight: 600;
  color: var(--text-primary);
}

.about-dev-role {
  font-size: 13px;
  color: var(--text-muted);
}

.about-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
  flex-shrink: 0;
}


/* Light mode overrides */
@media (prefers-color-scheme: light) {
  .about-card {
    background: rgba(255,255,255,0.8);
    border-color: rgba(0,0,0,0.08);
  }
}

[data-theme="light"] .about-card {
  background: rgba(255,255,255,0.8);
  border-color: rgba(0,0,0,0.08);
}

/* ===== 个性化页面 ===== */
.personalization-page {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 16px;
  overflow-y: auto;
}

.pers-card {
  background: var(--bg-card, rgba(255,255,255,0.06));
  border: 1px solid var(--border-color, rgba(255,255,255,0.08));
  border-radius: 12px;
  padding: 20px 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}

.pers-card-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 16px;
}

.pers-colors {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.pers-color-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  padding: 8px;
  border-radius: 10px;
  transition: background 0.15s ease;
  min-width: 64px;
}

.pers-color-item:hover {
  background: var(--bg-hover);
}

.pers-color-item.active {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 10px;
}

@media (prefers-color-scheme: light) {
  .pers-color-item.active {
    background: rgba(0, 0, 0, 0.04);
  }
}

.pers-color-swatch {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  flex-shrink: 0;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.pers-color-swatch .bi {
  color: #fff;
  font-size: 18px;
  font-weight: 700;
  filter: drop-shadow(0 1px 2px rgba(0,0,0,0.5));
}

.pers-color-picker {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  cursor: pointer;
  color: #fff;
  font-size: 16px;
}

.pers-color-input {
  position: absolute;
  inset: 0;
  opacity: 0;
  cursor: pointer;
  width: 100%;
  height: 100%;
}

.pers-color-name {
  font-size: 11px;
  color: var(--text-muted);
  white-space: nowrap;
}

.pers-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  font-size: 14px;
  color: var(--text-primary);
}

.pers-row + .pers-row {
  border-top: 1px solid var(--border-color);
}

.pers-toggle {
  position: relative;
  display: inline-block;
  width: 44px;
  height: 24px;
  cursor: pointer;
}

.pers-toggle input {
  opacity: 0;
  width: 0;
  height: 0;
}

.pers-toggle-slider {
  position: absolute;
  inset: 0;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  transition: background 0.2s ease;
}

.pers-toggle-slider::before {
  content: '';
  position: absolute;
  left: 2px;
  top: 2px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #fff;
  transition: transform 0.2s ease;
}

.pers-toggle input:checked + .pers-toggle-slider {
  background: var(--accent-primary);
}

.pers-toggle input:checked + .pers-toggle-slider::before {
  transform: translateX(20px);
}

.pers-speed {
  display: flex;
  align-items: center;
  gap: 10px;
}

.pers-slider {
  width: 140px;
  height: 4px;
  -webkit-appearance: none;
  appearance: none;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 2px;
  outline: none;
  cursor: pointer;
}

.pers-slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--accent-primary);
  cursor: pointer;
  border: 2px solid #fff;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
}

.pers-slider::-moz-range-thumb {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--accent-primary);
  cursor: pointer;
  border: 2px solid #fff;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
}

.pers-speed-label {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-primary);
  min-width: 36px;
  text-align: right;
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
}

.pers-input {
  background: rgba(255,255,255,0.08);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 8px 12px;
  color: var(--text-primary);
  font-size: 14px;
  outline: none;
  width: 200px;
  transition: border-color 0.15s ease;
}

.pers-input:focus {
  border-color: var(--accent-primary);
}

@media (prefers-color-scheme: light) {
  .pers-input {
    background: rgba(0,0,0,0.04);
  }
}

.pers-effects {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.pers-effect-item {
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-secondary);
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border-color);
  cursor: pointer;
  transition: all 0.15s ease;
}

.pers-effect-item:hover {
  background: rgba(255, 255, 255, 0.1);
  color: var(--text-primary);
}

.pers-effect-item.active {
  background: var(--accent-primary);
  color: #fff;
  border-color: var(--accent-primary);
}

@media (prefers-color-scheme: light) {
  .pers-card {
    background: rgba(255,255,255,0.8);
    border-color: rgba(0,0,0,0.08);
  }
  .pers-effect-item {
    background: rgba(0, 0, 0, 0.04);
  }
  .pers-effect-item:hover {
    background: rgba(0, 0, 0, 0.08);
  }
  .pers-toggle-slider {
    background: rgba(0, 0, 0, 0.15);
  }
  .pers-slider {
    background: rgba(0, 0, 0, 0.15);
  }
}

[data-theme="light"] .pers-card {
  background: rgba(255,255,255,0.8);
  border-color: rgba(0,0,0,0.08);
}

/* 背景选择 */
.pers-bg-types {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.pers-bg-type-item {
  padding: 8px 20px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-secondary);
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border-color);
  cursor: pointer;
  transition: all 0.15s ease;
}

.pers-bg-type-item:hover {
  background: rgba(255, 255, 255, 0.1);
  color: var(--text-primary);
}

.pers-bg-type-item.active {
  background: var(--accent-primary);
  color: #fff;
  border-color: var(--accent-primary);
}

.pers-bg-solid {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 12px;
}

.pers-color-input-inline {
  width: 36px;
  height: 36px;
  border: none;
  border-radius: 8px;
  padding: 0;
  cursor: pointer;
  background: none;
}

.pers-color-input-inline::-webkit-color-swatch-wrapper {
  padding: 0;
}

.pers-color-input-inline::-webkit-color-swatch {
  border: 1px solid var(--border-color);
  border-radius: 8px;
}

.pers-color-hex {
  font-size: 13px;
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
  color: var(--text-muted);
}

/* 背景 - 图片/视频 */
.pers-bg-media {
  margin-top: 12px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.pers-bg-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.pers-bg-section-label {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-muted);
}

.pers-fit-modes {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.pers-fit-item {
  padding: 6px 14px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-secondary);
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border-color);
  cursor: pointer;
  transition: all 0.15s ease;
}

.pers-fit-item:hover {
  background: rgba(255, 255, 255, 0.1);
  color: var(--text-primary);
}

.pers-fit-item.active {
  background: var(--accent-primary);
  color: #fff;
  border-color: var(--accent-primary);
}

.pers-bg-loading,
.pers-bg-empty {
  font-size: 12px;
  color: var(--text-muted);
  padding: 8px 0;
}

.pers-bg-files {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  max-height: 120px;
  overflow-y: auto;
}

.pers-bg-file {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 12px;
  color: var(--text-secondary);
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border-color);
  cursor: pointer;
  transition: all 0.15s ease;
  max-width: 200px;
}

.pers-bg-file:hover {
  background: rgba(255, 255, 255, 0.1);
  color: var(--text-primary);
}

.pers-bg-file.active {
  background: var(--accent-primary);
  color: #fff;
  border-color: var(--accent-primary);
}

.pers-bg-file i {
  font-size: 14px;
  flex-shrink: 0;
}

.pers-bg-file-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.pers-bg-url-row {
  display: flex;
  gap: 8px;
  align-items: center;
}

.pers-bg-url-input {
  flex: 1;
}

.pers-bg-url-btn {
  flex-shrink: 0;
  padding: 8px 16px;
  font-size: 13px;
}

.pers-bg-current {
  font-size: 12px;
  color: var(--text-muted);
  padding: 4px 0;
  word-break: break-all;
}

/* 开关 (toggle) */
.pers-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 0;
  font-size: 14px;
  color: var(--text-primary);
}

.pers-toggle {
  width: 44px;
  height: 24px;
  border-radius: 12px;
  background: rgba(255,255,255,0.15);
  cursor: pointer;
  position: relative;
  transition: background 0.2s;
  flex-shrink: 0;
}

.pers-toggle.active {
  background: var(--accent-primary);
}

.pers-toggle-knob {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #fff;
  position: absolute;
  top: 2px;
  left: 2px;
  transition: left 0.2s;
  box-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.pers-toggle.active .pers-toggle-knob {
  left: 22px;
}

/* 滑块 (range) */
.pers-slider-row {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 8px;
  font-size: 13px;
  color: var(--text-secondary);
}

.pers-range {
  flex: 1;
  max-width: 200px;
  -webkit-appearance: none;
  appearance: none;
  height: 4px;
  border-radius: 2px;
  background: rgba(255,255,255,0.2);
  outline: none;
}

.pers-range::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--accent-primary);
  cursor: pointer;
  border: 2px solid #fff;
  box-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.pers-range-value {
  min-width: 36px;
  text-align: right;
  font-family: 'Cascadia Code', monospace;
  font-size: 12px;
  color: var(--text-muted);
}

/* 音乐 */
.pers-music-modes {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.pers-music-mode-item {
  padding: 6px 14px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-secondary);
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border-color);
  cursor: pointer;
  transition: all 0.15s ease;
}

.pers-music-mode-item:hover {
  background: rgba(255, 255, 255, 0.1);
  color: var(--text-primary);
}

.pers-music-mode-item.active {
  background: var(--accent-primary);
  color: #fff;
  border-color: var(--accent-primary);
}

.pers-music-file {
  margin-top: 10px;
}

.pers-music-url {
  margin-top: 10px;
}

@media (prefers-color-scheme: light) {
  .pers-bg-type-item {
    background: rgba(0, 0, 0, 0.04);
  }
  .pers-bg-type-item:hover {
    background: rgba(0, 0, 0, 0.08);
  }
}

/* ===== MC Link revamp 适配器账号 ===== */
.revamp-badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  background: var(--accent-primary);
  color: #fff;
  vertical-align: middle;
  margin-left: 8px;
}

.revamp-server-info {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: var(--text-muted);
  margin-bottom: 8px;
  padding: 6px 0;
}

.revamp-server-info code {
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
  background: rgba(255,255,255,0.06);
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 12px;
}

.revamp-status-online {
  color: #10b981;
  font-size: 14px;
  font-weight: 500;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.revamp-status-offline {
  color: var(--text-muted);
  font-size: 14px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.revamp-user {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
}

.revamp-actions {
  display: flex;
  gap: 8px;
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid var(--border-color);
}

/* ===== revamp 加载遮罩 ===== */
.revamp-loading-overlay {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.55);
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  z-index: 10;
  backdrop-filter: blur(2px);
}

.revamp-spinner {
  width: 36px;
  height: 36px;
  border: 3px solid rgba(255, 255, 255, 0.15);
  border-top-color: var(--accent-primary);
  border-radius: 50%;
  animation: revamp-spin 0.8s linear infinite;
}

.revamp-loading-overlay span {
  font-size: 14px;
  color: #fff;
  font-weight: 500;
}

@keyframes revamp-spin {
  to { transform: rotate(360deg); }
}
</style>
